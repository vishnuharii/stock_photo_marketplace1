﻿namespace Stock_Photo_Marketplace.Models
{
    public class Category
    {
        public int CategoryID { get; set; } // Primary Key
        public string CategoryName { get; set; }
    }
}